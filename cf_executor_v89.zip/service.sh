#!/system/bin/sh
# CF Executor v8.7 启动器
MODDIR="/data/adb/modules/cf_executor"
LOCKFILE="/sdcard/cf_executor/.daemon_lock"
mkdir -p /sdcard/cf_executor "$MODDIR/webroot/work" 2>/dev/null
chmod 700 /sdcard/cf_executor "$MODDIR/webroot/work" 2>/dev/null
# 强制终止所有旧实例 (包括僵尸进程)
killall -15 cf_daemon 2>/dev/null
sleep 2
killall -9 cf_daemon 2>/dev/null
sleep 1
# 清理残留锁文件 + 卸载 mount --bind 伪装
rm -f "$LOCKFILE" 2>/dev/null
umount -l "$MODDIR/cf_daemon" 2>/dev/null
# 恢复原始二进制文件 (mount --bind 会覆盖, 需要重新设置权限)
chmod 755 "$MODDIR/cf_daemon" 2>/dev/null
chmod 755 "$MODDIR/jj" 2>/dev/null
# v8.7: 在 daemon disguise 之前复制签名用副本, disguise 会 mount --bind sh 覆盖 cf_daemon
# 之后 WebUI 调用 cf_daemon --sign 会执行 sh 而非原二进制, 因此用 cf_sign 副本代替
rm -f "$MODDIR/cf_sign" 2>/dev/null
cp "$MODDIR/cf_daemon" "$MODDIR/cf_sign"
chmod 755 "$MODDIR/cf_sign"
# 启动守护进程，崩溃自动重启 (指数退避: 3s→6s→12s→24s→max 60s)
delay=3
while true; do
    # 写锁文件标记 daemon 已启动
    echo "$$" > "$LOCKFILE"
    "$MODDIR/cf_daemon" >> /sdcard/cf_executor/daemon.log 2>&1
    rm -f "$LOCKFILE" 2>/dev/null
    sleep $delay
    if [ $delay -lt 60 ]; then
        delay=$((delay * 2))
    fi
done