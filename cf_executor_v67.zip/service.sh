#!/system/bin/sh
# CF Executor v6.0 启动器
MODDIR="/data/adb/modules/cf_executor"
LOCKFILE="/sdcard/cf_executor/.daemon_lock"
mkdir -p /sdcard/cf_executor "$MODDIR/webroot/work" 2>/dev/null
chmod 700 /sdcard/cf_executor "$MODDIR/webroot/work" 2>/dev/null
chmod 755 "$MODDIR/cf_daemon" 2>/dev/null
chmod 755 "$MODDIR/jj" 2>/dev/null
# 强制终止所有旧实例 (包括僵尸进程)
killall -15 cf_daemon 2>/dev/null
sleep 2
killall -9 cf_daemon 2>/dev/null
sleep 1
# 清理残留锁文件
rm -f "$LOCKFILE" 2>/dev/null
# 启动守护进程，崩溃自动重启 (指数退避: 3s→6s→12s→24s→max 60s)
delay=3
while true; do
    # 写锁文件标记 daemon 已启动
    echo "$$" > "$LOCKFILE"
    "$MODDIR/cf_daemon" >> /sdcard/cf_executor/daemon.log 2>&1
    rm -f "$LOCKFILE" 2>/dev/null
    sleep $delay
    if [ $delay -lt 60 ]; then
        delay=$((delay * 2))
    fi
done