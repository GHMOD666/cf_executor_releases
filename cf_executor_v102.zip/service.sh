#!/system/bin/sh
MODDIR="/data/adb/modules/cf_executor"
LOCKFILE="/sdcard/cf_executor/.daemon_lock"
RESTART_LOG="/sdcard/cf_executor/.restart_log"
mkdir -p /sdcard/cf_executor "$MODDIR/webroot/work" 2>/dev/null
chmod 700 /sdcard/cf_executor "$MODDIR/webroot/work" 2>/dev/null

# 强制终止所有旧实例 (包括僵尸进程)
killall -15 cf_daemon 2>/dev/null
sleep 2
killall -9 cf_daemon 2>/dev/null
sleep 1

# 清理残留锁文件 + 卸载 mount --bind 伪装
rm -f "$LOCKFILE" 2>/dev/null
umount -l "$MODDIR/cf_daemon" 2>/dev/null

# 恢复原始二进制文件
chmod 755 "$MODDIR/cf_daemon" 2>/dev/null
chmod 755 "$MODDIR/jj" 2>/dev/null

# 复制签名用副本
rm -f "$MODDIR/cf_sign" 2>/dev/null
cp "$MODDIR/cf_daemon" "$MODDIR/cf_sign"
chmod 755 "$MODDIR/cf_sign"
RESTART_WINDOW=3600  # 1 小时窗口
MAX_RESTARTS=10       # 最多 10 次/小时
CURRENT_TS=$(date +%s)

if [ -f "$RESTART_LOG" ]; then
    # 清理 1 小时前的记录
    awk -v cutoff=$((CURRENT_TS - RESTART_WINDOW)) '$1 >= cutoff' "$RESTART_LOG" > "${RESTART_LOG}.tmp" 2>/dev/null
    mv "${RESTART_LOG}.tmp" "$RESTART_LOG" 2>/dev/null
fi

# 启动守护进程，崩溃自动重启
delay=3
restart_count=0

while true; do

    if [ -f "$RESTART_LOG" ]; then
        restart_count=$(wc -l < "$RESTART_LOG" 2>/dev/null)
        if [ "$restart_count" -ge "$MAX_RESTARTS" ]; then
            # 超过限制, 等待到窗口结束
            OLDEST=$(head -1 "$RESTART_LOG" 2>/dev/null | awk '{print $1}')
            WAIT_UNTIL=$((OLDEST + RESTART_WINDOW))
            WAIT_SEC=$((WAIT_UNTIL - CURRENT_TS))
            if [ "$WAIT_SEC" -gt 0 ]; then
                sleep "$WAIT_SEC"
                # 重新初始化
                exec "$0"
            fi
        fi
    fi

    # 写锁文件标记 daemon 已启动
    echo "$$" > "$LOCKFILE"
    

    if [ ! -x "$MODDIR/cf_daemon" ]; then
        sleep 10
        continue
    fi
    
    "$MODDIR/cf_daemon" >> /sdcard/cf_executor/daemon.log 2>&1
    exit_code=$?
    
    rm -f "$LOCKFILE" 2>/dev/null
    echo "$(date +%s) exit=$exit_code" >> "$RESTART_LOG"
    

    rm -f /sdcard/cf_executor/.nonces 2>/dev/null

    sleep $delay
    if [ $delay -lt 60 ]; then
        delay=$((delay * 2))
    fi
done