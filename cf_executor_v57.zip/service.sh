#!/system/bin/sh
# CF Executor L5+ v5 启动器
MODDIR="/data/adb/modules/cf_executor"
mkdir -p /sdcard/cf_executor "$MODDIR/webroot/work" 2>/dev/null
chmod 700 /sdcard/cf_executor "$MODDIR/webroot/work" 2>/dev/null
chmod 755 "$MODDIR/cf_daemon" 2>/dev/null
chmod 755 "$MODDIR/jj" 2>/dev/null
# 优雅终止旧实例
killall -15 cf_daemon 2>/dev/null
sleep 1
killall -9 cf_daemon 2>/dev/null
pkill -9 -f "cf_daemon" 2>/dev/null
# 启动守护进程，崩溃自动重启 (指数退避: 3s→6s→12s→24s→max 60s)
delay=3
while true; do
    "$MODDIR/cf_daemon" >> /sdcard/cf_executor/daemon.log 2>&1
    sleep $delay
    if [ $delay -lt 60 ]; then
        delay=$((delay * 2))
    fi
done