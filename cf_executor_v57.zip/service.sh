#!/system/bin/sh
# CF Executor L5+ v5 启动器
MODDIR="/data/adb/modules/cf_executor"
mkdir -p /sdcard/cf_executor "$MODDIR/webroot/work" 2>/dev/null
chmod 777 /sdcard/cf_executor "$MODDIR/webroot/work" 2>/dev/null
chmod 755 "$MODDIR/cf_daemon" 2>/dev/null
chmod 755 "$MODDIR/jj" 2>/dev/null
# 杀掉旧实例
killall -9 cf_daemon 2>/dev/null
pkill -9 -f "cf_daemon" 2>/dev/null
# 启动守护进程，崩溃自动重启
while true; do
    "$MODDIR/cf_daemon" >> /sdcard/cf_executor/daemon.log 2>&1
    sleep 3
done