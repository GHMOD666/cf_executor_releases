#!/system/bin/sh
# CF Executor L5+ v6 安装脚本
MODDIR="/data/adb/modules/cf_executor"
chmod 755 "$MODDIR/cf_daemon" 2>/dev/null
chmod 755 "$MODDIR/jj" 2>/dev/null
chmod 755 "$MODDIR/service.sh" 2>/dev/null
chmod 644 "$MODDIR/webroot/index.html" 2>/dev/null
mkdir -p "$MODDIR/webroot/work" 2>/dev/null
chmod 777 "$MODDIR/webroot/work" 2>/dev/null
mkdir -p /sdcard/cf_executor 2>/dev/null
chmod 777 /sdcard/cf_executor 2>/dev/null
rm -f "$MODDIR/.tampered" 2>/dev/null
# v16: 不再删除 status, daemon 自己会写